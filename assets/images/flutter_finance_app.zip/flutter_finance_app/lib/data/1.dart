class money{
  String? image;
  String? name;
  String? time;
  String? fee;
  bool? buy;
}